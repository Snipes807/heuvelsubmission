<?php
/**
 * 404 template.
 *
 * @package Heuvel
 */

get_header();
?>

<section class="error-404">
	<header class="page-head">
		<div class="container">
			<span class="eyebrow"><?php esc_html_e( 'Error 404', 'heuvel' ); ?></span>
			<h1><?php echo wp_kses( __( 'This room is <em>not</em> available', 'heuvel' ), array( 'em' => array() ) ); ?></h1>
		</div>
	</header>

	<div class="page-body">
		<div class="container container-narrow entry-content">
			<p><?php esc_html_e( 'The page you were looking for has moved or never existed. Try a search, or head back to the start.', 'heuvel' ); ?></p>
			<?php get_search_form(); ?>
			<p style="margin-top:40px">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn-dark"><?php esc_html_e( 'Back home', 'heuvel' ); ?> <span class="arrow" aria-hidden="true">&rarr;</span></a>
			</p>
		</div>
	</div>
</section>

<?php
get_footer();
