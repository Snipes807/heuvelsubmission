<?php
/**
 * Heuvel Hotel functions and definitions.
 *
 * @package Heuvel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'HEUVEL_VERSION', '1.0.0' );

/**
 * Theme setup.
 */
function heuvel_setup() {
	load_theme_textdomain( 'heuvel', get_template_directory() . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' )
	);
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 96,
			'width'       => 320,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	add_editor_style( array( heuvel_fonts_url(), 'assets/css/editor-style.css' ) );

	add_image_size( 'heuvel-card', 900, 1125, true );
	add_image_size( 'heuvel-wide', 2000, 1200, true );

	register_nav_menus(
		array(
			'primary' => __( 'Primary Menu', 'heuvel' ),
			'footer'  => __( 'Footer Menu', 'heuvel' ),
		)
	);
}
add_action( 'after_setup_theme', 'heuvel_setup' );

/**
 * Content width for embeds.
 */
function heuvel_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'heuvel_content_width', 760 );
}
add_action( 'after_setup_theme', 'heuvel_content_width', 0 );

/**
 * Google Fonts URL.
 */
function heuvel_fonts_url() {
	return 'https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400;0,500;1,400&family=Hanken+Grotesk:wght@400;500;600&display=swap';
}

/**
 * Preconnect to Google Fonts.
 */
function heuvel_resource_hints( $urls, $relation_type ) {
	if ( 'preconnect' === $relation_type ) {
		$urls[] = 'https://fonts.googleapis.com';
		$urls[] = array(
			'href' => 'https://fonts.gstatic.com',
			'crossorigin',
		);
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'heuvel_resource_hints', 10, 2 );

/**
 * Enqueue styles and scripts.
 */
function heuvel_scripts() {
	wp_enqueue_style( 'heuvel-fonts', heuvel_fonts_url(), array(), null );
	wp_enqueue_style( 'heuvel-style', get_stylesheet_uri(), array( 'heuvel-fonts' ), HEUVEL_VERSION );

	wp_enqueue_script(
		'heuvel-script',
		get_template_directory_uri() . '/assets/js/script.js',
		array(),
		HEUVEL_VERSION,
		array(
			'in_footer' => true,
			'strategy'  => 'defer',
		)
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'heuvel_scripts' );

/**
 * Flag JS support early so reveal animations never hide content without JS.
 */
function heuvel_js_class() {
	echo "<script>document.documentElement.classList.add('js');</script>\n";
}
add_action( 'wp_head', 'heuvel_js_class', 0 );

/**
 * Body classes.
 */
function heuvel_body_classes( $classes ) {
	if ( ! heuvel_has_hero() ) {
		$classes[] = 'has-solid-header';
	}
	return $classes;
}
add_filter( 'body_class', 'heuvel_body_classes' );

/**
 * Whether the current view shows the full-bleed hero.
 */
function heuvel_has_hero() {
	// front-page.php renders the hero whether the front page is a static page or the post list.
	return is_front_page();
}

/**
 * Shorter excerpts on cards.
 */
function heuvel_excerpt_length() {
	return 24;
}
add_filter( 'excerpt_length', 'heuvel_excerpt_length' );

function heuvel_excerpt_more() {
	return '&hellip;';
}
add_filter( 'excerpt_more', 'heuvel_excerpt_more' );

require get_template_directory() . '/inc/customizer.php';
require get_template_directory() . '/inc/template-tags.php';
