<?php
/**
 * Front page: hero, about, rooms and booking CTA.
 *
 * Content is edited in Appearance → Customize → Heuvel Front Page.
 *
 * @package Heuvel
 */

get_header();

get_template_part( 'template-parts/front/hero' );

$section = 0;

if ( heuvel_mod( 'about_show' ) ) {
	get_template_part( 'template-parts/front/about', null, array( 'number' => ++$section ) );
}

if ( heuvel_mod( 'rooms_show' ) ) {
	get_template_part( 'template-parts/front/rooms', null, array( 'number' => ++$section ) );
}

// If a static front page has content, show it between the rooms and the CTA.
if ( is_page() ) {
	while ( have_posts() ) {
		the_post();
		if ( '' !== trim( get_the_content() ) ) :
			?>
			<section class="section front-content">
				<div class="container container-narrow entry-content reveal">
					<?php the_content(); ?>
				</div>
			</section>
			<?php
		endif;
	}
}

if ( heuvel_mod( 'cta_show' ) ) {
	get_template_part( 'template-parts/front/cta', null, array( 'number' => ++$section ) );
}

get_footer();
