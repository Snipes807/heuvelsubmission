<?php
/**
 * Fallback template: blog index and anything without a more specific template.
 *
 * @package Heuvel
 */

get_header();
?>

<header class="page-head">
	<div class="container">
		<span class="eyebrow"><?php esc_html_e( 'Journal', 'heuvel' ); ?></span>
		<h1>
			<?php
			if ( is_home() && ! is_front_page() ) {
				single_post_title();
			} else {
				esc_html_e( 'Latest', 'heuvel' );
			}
			?>
		</h1>
	</div>
</header>

<?php get_template_part( 'template-parts/loop' ); ?>

<?php
get_footer();
