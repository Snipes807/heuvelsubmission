<?php
/**
 * Site header.
 *
 * @package Heuvel
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'heuvel' ); ?></a>

<header class="site-header<?php echo heuvel_has_hero() ? '' : ' scrolled'; ?>" id="siteHeader">
	<div class="container header-inner">
		<?php heuvel_logo(); ?>

		<button class="nav-toggle" id="navToggle" aria-label="<?php esc_attr_e( 'Toggle navigation', 'heuvel' ); ?>" aria-expanded="false" aria-controls="nav">
			<span></span><span></span>
		</button>

		<nav class="nav" id="nav" aria-label="<?php esc_attr_e( 'Primary', 'heuvel' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'container'      => false,
					'menu_class'     => 'menu',
					'depth'          => 1,
					'fallback_cb'    => 'heuvel_primary_menu_fallback',
				)
			);

			$button_text = heuvel_mod( 'header_button_text' );
			if ( $button_text ) :
				?>
				<a href="<?php echo heuvel_link( heuvel_mod( 'header_button_url' ) ); ?>" class="btn btn-light"><?php echo esc_html( $button_text ); ?></a>
			<?php endif; ?>
		</nav>
	</div>
</header>

<main id="content">
