<?php
/**
 * Post grid with pagination, shared by index, archive and search.
 *
 * @package Heuvel
 */

?>
<div class="page-body">
	<div class="container">
		<?php if ( have_posts() ) : ?>
			<div class="cards post-grid">
				<?php
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/content', 'card' );
				endwhile;
				?>
			</div>

			<?php
			the_posts_pagination(
				array(
					'mid_size'  => 1,
					'prev_text' => '&larr;<span class="screen-reader-text">' . esc_html__( 'Previous page', 'heuvel' ) . '</span>',
					'next_text' => '<span class="screen-reader-text">' . esc_html__( 'Next page', 'heuvel' ) . '</span>&rarr;',
				)
			);
			?>
		<?php else : ?>
			<?php get_template_part( 'template-parts/content', 'none' ); ?>
		<?php endif; ?>
	</div>
</div>
