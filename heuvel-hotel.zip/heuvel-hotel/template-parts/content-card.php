<?php
/**
 * Post card used in listings.
 *
 * @package Heuvel
 */

?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'card reveal' ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<a href="<?php the_permalink(); ?>" class="img-frame" tabindex="-1" aria-hidden="true">
			<?php the_post_thumbnail( 'heuvel-card', array( 'alt' => '' ) ); ?>
		</a>
	<?php endif; ?>

	<div class="card-head">
		<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
	</div>
	<span class="card-meta"><?php echo esc_html( get_the_date() ); ?></span>
	<p><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p>
	<a href="<?php the_permalink(); ?>" class="link-arrow">
		<?php esc_html_e( 'Read more', 'heuvel' ); ?>
		<span class="screen-reader-text"><?php the_title(); ?></span>
		<span class="arrow" aria-hidden="true">&rarr;</span>
	</a>
</article>
