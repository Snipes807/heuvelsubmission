<?php
/**
 * Shown when a query returns nothing.
 *
 * @package Heuvel
 */

?>
<section class="no-results container-narrow entry-content">
	<?php if ( is_search() ) : ?>
		<p><?php esc_html_e( 'Nothing matched your search. Try different words.', 'heuvel' ); ?></p>
	<?php else : ?>
		<p><?php esc_html_e( 'There is nothing here yet.', 'heuvel' ); ?></p>
	<?php endif; ?>
	<?php get_search_form(); ?>
</section>
