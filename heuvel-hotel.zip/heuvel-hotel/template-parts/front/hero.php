<?php
/**
 * Front page hero.
 *
 * @package Heuvel
 */

$eyebrow     = heuvel_mod( 'hero_eyebrow' );
$text        = heuvel_mod( 'hero_text' );
$button_text = heuvel_mod( 'hero_button_text' );
?>
<section class="hero">
	<?php
	heuvel_image(
		heuvel_mod( 'hero_image' ),
		heuvel_mod( 'hero_image_alt' ),
		'full',
		array(
			'class'         => 'hero-bg',
			'loading'       => 'eager',
			'fetchpriority' => 'high',
		)
	);
	?>
	<div class="hero-overlay"></div>

	<div class="container hero-inner">
		<div class="hero-title">
			<?php if ( $eyebrow ) : ?>
				<p class="eyebrow eyebrow-light"><?php echo esc_html( $eyebrow ); ?></p>
			<?php endif; ?>
			<h1><?php heuvel_inline( heuvel_mod( 'hero_title' ) ); ?></h1>
		</div>

		<?php if ( $text || $button_text ) : ?>
			<div class="hero-side">
				<?php if ( $text ) : ?>
					<p><?php echo wp_kses_post( $text ); ?></p>
				<?php endif; ?>
				<?php if ( $button_text ) : ?>
					<a href="<?php echo heuvel_link( heuvel_mod( 'hero_button_url' ) ); ?>" class="btn btn-outline-light"><?php echo esc_html( $button_text ); ?> <span class="arrow" aria-hidden="true">&rarr;</span></a>
				<?php endif; ?>
			</div>
		<?php endif; ?>
	</div>
</section>
