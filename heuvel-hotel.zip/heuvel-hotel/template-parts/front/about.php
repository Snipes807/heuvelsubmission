<?php
/**
 * Front page "about" section.
 *
 * @package Heuvel
 */

$number    = isset( $args['number'] ) ? $args['number'] : 1;
$link_text = heuvel_mod( 'about_link_text' );
$image     = heuvel_mod( 'about_image' );
$caption   = heuvel_mod( 'about_caption' );
$aside     = heuvel_mod( 'about_caption_aside' );
?>
<section class="section about" id="about">
	<div class="container about-grid">
		<div class="about-text reveal">
			<div class="section-label">
				<?php heuvel_section_number( $number ); ?>
				<span class="rule"></span>
				<span class="eyebrow"><?php echo esc_html( heuvel_mod( 'about_eyebrow' ) ); ?></span>
			</div>
			<h2><?php heuvel_inline( heuvel_mod( 'about_title' ) ); ?></h2>
			<?php echo wp_kses_post( wpautop( heuvel_mod( 'about_text' ) ) ); ?>
			<?php if ( $link_text ) : ?>
				<a href="<?php echo heuvel_link( heuvel_mod( 'about_link_url' ) ); ?>" class="link-arrow"><?php echo esc_html( $link_text ); ?> <span class="arrow" aria-hidden="true">&rarr;</span></a>
			<?php endif; ?>
		</div>

		<?php if ( $image ) : ?>
			<figure class="about-figure reveal">
				<div class="img-frame">
					<?php heuvel_image( $image, heuvel_mod( 'about_image_alt' ), 'large' ); ?>
				</div>
				<?php if ( $caption || $aside ) : ?>
					<figcaption>
						<span><?php echo esc_html( $caption ); ?></span>
						<em><?php echo esc_html( $aside ); ?></em>
					</figcaption>
				<?php endif; ?>
			</figure>
		<?php endif; ?>
	</div>
</section>
