<?php
/**
 * Front page rooms section with three cards.
 *
 * @package Heuvel
 */

$number = isset( $args['number'] ) ? $args['number'] : 2;
$intro  = heuvel_mod( 'rooms_intro' );
?>
<section class="section rooms" id="rooms">
	<div class="container">
		<div class="rooms-head reveal">
			<div>
				<div class="section-label">
					<?php heuvel_section_number( $number ); ?>
					<span class="rule"></span>
					<span class="eyebrow"><?php echo esc_html( heuvel_mod( 'rooms_eyebrow' ) ); ?></span>
				</div>
				<h2><?php heuvel_inline( heuvel_mod( 'rooms_title' ) ); ?></h2>
			</div>
			<?php if ( $intro ) : ?>
				<p><?php echo wp_kses_post( $intro ); ?></p>
			<?php endif; ?>
		</div>

		<div class="cards">
			<?php
			for ( $i = 1; $i <= 3; $i++ ) :
				$title = heuvel_mod( "room_{$i}_title" );
				if ( ! $title ) {
					continue;
				}
				$text      = heuvel_mod( "room_{$i}_text" );
				$link_text = heuvel_mod( "room_{$i}_link_text" );
				?>
				<article class="card reveal">
					<div class="img-frame">
						<?php heuvel_image( heuvel_mod( "room_{$i}_image" ), heuvel_mod( "room_{$i}_image_alt" ), 'heuvel-card' ); ?>
					</div>
					<div class="card-head">
						<h3><?php echo esc_html( $title ); ?></h3>
						<span class="roman"><?php echo esc_html( heuvel_roman( $i ) ); ?></span>
					</div>
					<?php if ( $text ) : ?>
						<p><?php echo wp_kses_post( $text ); ?></p>
					<?php endif; ?>
					<?php if ( $link_text ) : ?>
						<a href="<?php echo heuvel_link( heuvel_mod( "room_{$i}_link_url" ) ); ?>" class="link-arrow"><?php echo esc_html( $link_text ); ?> <span class="arrow" aria-hidden="true">&rarr;</span></a>
					<?php endif; ?>
				</article>
			<?php endfor; ?>
		</div>
	</div>
</section>
