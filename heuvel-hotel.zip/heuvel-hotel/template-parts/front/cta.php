<?php
/**
 * Front page booking call to action.
 *
 * @package Heuvel
 */

$number      = isset( $args['number'] ) ? $args['number'] : 3;
$text        = heuvel_mod( 'cta_text' );
$button_text = heuvel_mod( 'cta_button_text' );
?>
<section class="section cta" id="book">
	<div class="container cta-inner reveal">
		<?php heuvel_section_number( $number ); ?>
		<h2><?php heuvel_inline( heuvel_mod( 'cta_title' ) ); ?></h2>
		<?php if ( $text ) : ?>
			<p><?php echo wp_kses_post( $text ); ?></p>
		<?php endif; ?>
		<?php if ( $button_text ) : ?>
			<a href="<?php echo heuvel_link( heuvel_mod( 'cta_button_url' ) ); ?>" class="btn btn-dark"><?php echo esc_html( $button_text ); ?> <span class="arrow" aria-hidden="true">&rarr;</span></a>
		<?php endif; ?>
	</div>
</section>
