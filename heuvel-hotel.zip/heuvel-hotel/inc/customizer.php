<?php
/**
 * Customizer settings for the front page.
 *
 * Every front-page string and image lives here so the page can be edited
 * from Appearance → Customize without touching templates.
 *
 * @package Heuvel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Default values for every theme mod.
 */
function heuvel_defaults() {
	$img = 'https://images.unsplash.com/';

	return array(
		// Header.
		'header_button_text'  => 'Lorem ipsum',
		'header_button_url'   => '#book',

		// Hero.
		'hero_image'          => $img . 'photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&w=2000&q=80',
		'hero_image_alt'      => 'Sunlit hotel lounge with leather sofa and plants',
		'hero_eyebrow'        => 'Lorem ipsum dolor',
		'hero_title'          => '<span>Lorem ipsum</span><br><em>dolor</em> sit amet',
		'hero_text'           => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante venenatis dapibus posuere velit aliquet.',
		'hero_button_text'    => 'Consectetur',
		'hero_button_url'     => '#about',

		// About.
		'about_show'          => true,
		'about_eyebrow'       => 'Lorem ipsum',
		'about_title'         => 'Lorem ipsum<br>dolor sit amet,<br><em>consectetur</em> adipiscing',
		'about_text'          => "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.\n\nDuis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.",
		'about_link_text'     => 'Lorem ipsum',
		'about_link_url'      => '#rooms',
		'about_image'         => $img . 'photo-1631049307264-da0ec9d70304?auto=format&fit=crop&w=1200&q=80',
		'about_image_alt'     => 'Bedroom with upholstered bed and city view',
		'about_caption'       => 'Lorem ipsum dolor',
		'about_caption_aside' => 'Sit amet',

		// Rooms.
		'rooms_show'          => true,
		'rooms_eyebrow'       => 'Dolor sit',
		'rooms_title'         => 'Lorem ipsum <em>dolor</em> sit',
		'rooms_intro'         => 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.',

		'room_1_image'        => $img . 'photo-1611892440504-42a792e24d32?auto=format&fit=crop&w=900&q=80',
		'room_1_image_alt'    => 'Bright hotel room with large window',
		'room_1_title'        => 'Lorem ipsum',
		'room_1_text'         => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor.',
		'room_1_link_text'    => 'Lorem ipsum',
		'room_1_link_url'     => '#book',

		'room_2_image'        => $img . 'photo-1590490360182-c33d57733427?auto=format&fit=crop&w=900&q=80',
		'room_2_image_alt'    => 'Warmly lit hotel suite',
		'room_2_title'        => 'Dolor sit',
		'room_2_text'         => 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi.',
		'room_2_link_text'    => 'Lorem ipsum',
		'room_2_link_url'     => '#book',

		'room_3_image'        => $img . 'photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=900&q=80',
		'room_3_image_alt'    => 'Resort pool with lounge chairs',
		'room_3_title'        => 'Amet consectetur',
		'room_3_text'         => 'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum.',
		'room_3_link_text'    => 'Lorem ipsum',
		'room_3_link_url'     => '#book',

		// CTA.
		'cta_show'            => true,
		'cta_title'           => 'Lorem ipsum<br><em>dolor</em> sit amet',
		'cta_text'            => 'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit.',
		'cta_button_text'     => 'Lorem ipsum',
		'cta_button_url'      => '#',

		// Footer.
		'footer_note'         => 'Fictional hotel — design test only. All content and imagery are placeholders.',
	);
}

/**
 * Get a theme mod, falling back to the theme default.
 *
 * @param string $key Setting key.
 * @return mixed
 */
function heuvel_mod( $key ) {
	$defaults = heuvel_defaults();
	return get_theme_mod( $key, isset( $defaults[ $key ] ) ? $defaults[ $key ] : '' );
}

/**
 * Allow a small set of inline tags in headings.
 *
 * @param string $value Raw value.
 * @return string
 */
function heuvel_sanitize_inline( $value ) {
	return wp_kses( $value, heuvel_inline_tags() );
}

function heuvel_inline_tags() {
	return array(
		'em'     => array(),
		'strong' => array(),
		'br'     => array(),
		'span'   => array( 'class' => true ),
	);
}

function heuvel_sanitize_checkbox( $value ) {
	return (bool) $value;
}

/**
 * Register panels, sections, settings and controls.
 *
 * @param WP_Customize_Manager $wp_customize Customizer object.
 */
function heuvel_customize_register( $wp_customize ) {
	$wp_customize->add_panel(
		'heuvel_front',
		array(
			'title'       => __( 'Heuvel Front Page', 'heuvel' ),
			'description' => __( 'Headings accept &lt;em&gt;, &lt;strong&gt;, &lt;span&gt; and &lt;br&gt;.', 'heuvel' ),
			'priority'    => 30,
		)
	);

	$sections = array(
		'heuvel_header' => __( 'Header', 'heuvel' ),
		'heuvel_hero'   => __( 'Hero', 'heuvel' ),
		'heuvel_about'  => __( 'N° 01 — About', 'heuvel' ),
		'heuvel_rooms'  => __( 'N° 02 — Rooms', 'heuvel' ),
		'heuvel_cta'    => __( 'N° 03 — Booking CTA', 'heuvel' ),
		'heuvel_footer' => __( 'Footer', 'heuvel' ),
	);
	foreach ( $sections as $id => $title ) {
		$wp_customize->add_section( $id, array( 'title' => $title, 'panel' => 'heuvel_front' ) );
	}

	// key => array( section, type, label ).
	$fields = array(
		'header_button_text'  => array( 'heuvel_header', 'text', __( 'Button text', 'heuvel' ) ),
		'header_button_url'   => array( 'heuvel_header', 'url', __( 'Button link', 'heuvel' ) ),

		'hero_image'          => array( 'heuvel_hero', 'image', __( 'Background image', 'heuvel' ) ),
		'hero_image_alt'      => array( 'heuvel_hero', 'text', __( 'Image alt text', 'heuvel' ) ),
		'hero_eyebrow'        => array( 'heuvel_hero', 'text', __( 'Eyebrow', 'heuvel' ) ),
		'hero_title'          => array( 'heuvel_hero', 'inline', __( 'Heading', 'heuvel' ) ),
		'hero_text'           => array( 'heuvel_hero', 'textarea', __( 'Intro text', 'heuvel' ) ),
		'hero_button_text'    => array( 'heuvel_hero', 'text', __( 'Button text', 'heuvel' ) ),
		'hero_button_url'     => array( 'heuvel_hero', 'url', __( 'Button link', 'heuvel' ) ),

		'about_show'          => array( 'heuvel_about', 'checkbox', __( 'Show this section', 'heuvel' ) ),
		'about_eyebrow'       => array( 'heuvel_about', 'text', __( 'Eyebrow', 'heuvel' ) ),
		'about_title'         => array( 'heuvel_about', 'inline', __( 'Heading', 'heuvel' ) ),
		'about_text'          => array( 'heuvel_about', 'textarea', __( 'Body (blank line = new paragraph)', 'heuvel' ) ),
		'about_link_text'     => array( 'heuvel_about', 'text', __( 'Link text', 'heuvel' ) ),
		'about_link_url'      => array( 'heuvel_about', 'url', __( 'Link URL', 'heuvel' ) ),
		'about_image'         => array( 'heuvel_about', 'image', __( 'Image', 'heuvel' ) ),
		'about_image_alt'     => array( 'heuvel_about', 'text', __( 'Image alt text', 'heuvel' ) ),
		'about_caption'       => array( 'heuvel_about', 'text', __( 'Caption', 'heuvel' ) ),
		'about_caption_aside' => array( 'heuvel_about', 'text', __( 'Caption (italic, right)', 'heuvel' ) ),

		'rooms_show'          => array( 'heuvel_rooms', 'checkbox', __( 'Show this section', 'heuvel' ) ),
		'rooms_eyebrow'       => array( 'heuvel_rooms', 'text', __( 'Eyebrow', 'heuvel' ) ),
		'rooms_title'         => array( 'heuvel_rooms', 'inline', __( 'Heading', 'heuvel' ) ),
		'rooms_intro'         => array( 'heuvel_rooms', 'textarea', __( 'Intro text', 'heuvel' ) ),
	);

	for ( $i = 1; $i <= 3; $i++ ) {
		/* translators: %d: room card number. */
		$prefix = sprintf( __( 'Card %d:', 'heuvel' ), $i ) . ' ';

		$fields[ "room_{$i}_image" ]     = array( 'heuvel_rooms', 'image', $prefix . __( 'image', 'heuvel' ) );
		$fields[ "room_{$i}_image_alt" ] = array( 'heuvel_rooms', 'text', $prefix . __( 'image alt text', 'heuvel' ) );
		$fields[ "room_{$i}_title" ]     = array( 'heuvel_rooms', 'text', $prefix . __( 'title', 'heuvel' ) );
		$fields[ "room_{$i}_text" ]      = array( 'heuvel_rooms', 'textarea', $prefix . __( 'text', 'heuvel' ) );
		$fields[ "room_{$i}_link_text" ] = array( 'heuvel_rooms', 'text', $prefix . __( 'link text', 'heuvel' ) );
		$fields[ "room_{$i}_link_url" ]  = array( 'heuvel_rooms', 'url', $prefix . __( 'link URL', 'heuvel' ) );
	}

	$fields += array(
		'cta_show'            => array( 'heuvel_cta', 'checkbox', __( 'Show this section', 'heuvel' ) ),
		'cta_title'           => array( 'heuvel_cta', 'inline', __( 'Heading', 'heuvel' ) ),
		'cta_text'            => array( 'heuvel_cta', 'textarea', __( 'Text', 'heuvel' ) ),
		'cta_button_text'     => array( 'heuvel_cta', 'text', __( 'Button text', 'heuvel' ) ),
		'cta_button_url'      => array( 'heuvel_cta', 'url', __( 'Button link', 'heuvel' ) ),

		'footer_note'         => array( 'heuvel_footer', 'textarea', __( 'Footer note', 'heuvel' ) ),
	);

	$defaults = heuvel_defaults();

	foreach ( $fields as $key => $field ) {
		list( $section, $type, $label ) = $field;

		switch ( $type ) {
			case 'image':
			case 'url':
				$sanitize = 'esc_url_raw';
				break;
			case 'checkbox':
				$sanitize = 'heuvel_sanitize_checkbox';
				break;
			case 'inline':
				$sanitize = 'heuvel_sanitize_inline';
				break;
			case 'textarea':
				$sanitize = 'wp_kses_post';
				break;
			default:
				$sanitize = 'sanitize_text_field';
		}

		$wp_customize->add_setting(
			$key,
			array(
				'default'           => $defaults[ $key ],
				'sanitize_callback' => $sanitize,
				'transport'         => 'refresh',
			)
		);

		if ( 'image' === $type ) {
			$wp_customize->add_control(
				new WP_Customize_Image_Control(
					$wp_customize,
					$key,
					array(
						'label'   => $label,
						'section' => $section,
					)
				)
			);
			continue;
		}

		$wp_customize->add_control(
			$key,
			array(
				'label'   => $label,
				'section' => $section,
				'type'    => 'inline' === $type ? 'text' : $type,
			)
		);
	}
}
add_action( 'customize_register', 'heuvel_customize_register' );
