<?php
/**
 * Template helpers.
 *
 * @package Heuvel
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolve an in-page anchor (e.g. "#rooms") so it still works off the front page.
 *
 * @param string $url URL or anchor.
 * @return string Escaped URL.
 */
function heuvel_link( $url ) {
	if ( is_string( $url ) && 0 === strpos( $url, '#' ) && ! is_front_page() && '#' !== $url ) {
		$url = home_url( '/' ) . $url;
	}
	return esc_url( $url );
}

/**
 * Print an image from a Customizer URL, using responsive markup when it is a
 * Media Library attachment.
 *
 * @param string $url   Image URL.
 * @param string $alt   Alt text.
 * @param string $size  Registered image size.
 * @param array  $attrs Extra attributes.
 */
function heuvel_image( $url, $alt = '', $size = 'large', $attrs = array() ) {
	if ( ! $url ) {
		return;
	}

	$attrs = array_merge( array( 'alt' => $alt, 'loading' => 'lazy' ), $attrs );

	$id = attachment_url_to_postid( $url );
	if ( $id ) {
		echo wp_get_attachment_image( $id, $size, false, $attrs );
		return;
	}

	$html = '<img src="' . esc_url( $url ) . '"';
	foreach ( $attrs as $name => $value ) {
		$html .= ' ' . esc_attr( $name ) . '="' . esc_attr( $value ) . '"';
	}
	echo $html . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
}

/**
 * Print a heading string that may contain inline tags.
 *
 * @param string $value Heading.
 */
function heuvel_inline( $value ) {
	echo wp_kses( $value, heuvel_inline_tags() );
}

/**
 * Site logo: custom logo if set, otherwise the two-part wordmark.
 *
 * @param string $class Extra class.
 */
function heuvel_logo( $class = '' ) {
	if ( has_custom_logo() && '' === $class ) {
		the_custom_logo();
		return;
	}

	$name  = get_bloginfo( 'name' );
	$parts = explode( ' ', $name, 2 );
	?>
	<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo <?php echo esc_attr( $class ); ?>" rel="home">
		<?php echo esc_html( $parts[0] ); ?>
		<?php if ( isset( $parts[1] ) ) : ?>
			<span><?php echo esc_html( $parts[1] ); ?></span>
		<?php endif; ?>
	</a>
	<?php
}

/**
 * Fallback for the primary menu when none is assigned.
 */
function heuvel_primary_menu_fallback() {
	$links = array(
		'#about' => __( 'Lorem', 'heuvel' ),
		'#rooms' => __( 'Ipsum', 'heuvel' ),
		'#book'  => __( 'Dolor', 'heuvel' ),
	);

	echo '<ul class="menu">';
	foreach ( $links as $href => $label ) {
		printf( '<li><a href="%s">%s</a></li>', heuvel_link( $href ), esc_html( $label ) );
	}
	echo '</ul>';
}

/**
 * Fallback for the footer menu.
 */
function heuvel_footer_menu_fallback() {
	heuvel_primary_menu_fallback();
}

/**
 * The "N° 01" section number.
 *
 * @param int $n Number.
 */
function heuvel_section_number( $n ) {
	printf( '<span class="num">N<sup>o</sup> %s</span>', esc_html( str_pad( (string) $n, 2, '0', STR_PAD_LEFT ) ) );
}

/**
 * Lowercase roman numeral with trailing dot (i., ii., iii.).
 *
 * @param int $n Number (1–39).
 * @return string
 */
function heuvel_roman( $n ) {
	$map = array( 'x' => 10, 'ix' => 9, 'v' => 5, 'iv' => 4, 'i' => 1 );
	$out = '';
	foreach ( $map as $numeral => $value ) {
		while ( $n >= $value ) {
			$out .= $numeral;
			$n   -= $value;
		}
	}
	return $out . '.';
}

/**
 * Post date and author line.
 */
function heuvel_posted_on() {
	printf(
		'<time datetime="%1$s">%2$s</time> &middot; %3$s',
		esc_attr( get_the_date( DATE_W3C ) ),
		esc_html( get_the_date() ),
		esc_html( get_the_author() )
	);
}

/**
 * Categories and tags under a single post.
 */
function heuvel_entry_footer() {
	if ( 'post' !== get_post_type() ) {
		return;
	}

	$cats = get_the_category_list( ', ' );
	$tags = get_the_tag_list( '', ', ' );

	if ( ! $cats && ! $tags ) {
		return;
	}

	echo '<footer class="entry-footer">';
	if ( $cats ) {
		/* translators: %s: category list. */
		printf( '<p>' . esc_html__( 'Filed under %s', 'heuvel' ) . '</p>', $cats ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
	if ( $tags ) {
		/* translators: %s: tag list. */
		printf( '<p>' . esc_html__( 'Tagged %s', 'heuvel' ) . '</p>', $tags ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
	echo '</footer>';
}
