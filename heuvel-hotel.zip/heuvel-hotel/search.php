<?php
/**
 * Search results.
 *
 * @package Heuvel
 */

get_header();
?>

<header class="page-head">
	<div class="container">
		<span class="eyebrow"><?php esc_html_e( 'Search', 'heuvel' ); ?></span>
		<h1>
			<?php
			/* translators: %s: search query. */
			printf( esc_html__( 'Results for “%s”', 'heuvel' ), '<em>' . esc_html( get_search_query() ) . '</em>' );
			?>
		</h1>
	</div>
</header>

<?php get_template_part( 'template-parts/loop' ); ?>

<?php
get_footer();
