<?php
/**
 * Site footer.
 *
 * @package Heuvel
 */

?>
</main>

<footer class="site-footer">
	<div class="container">
		<div class="footer-top">
			<?php heuvel_logo( 'logo-lg' ); ?>
			<nav class="footer-nav" aria-label="<?php esc_attr_e( 'Footer', 'heuvel' ); ?>">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'footer',
						'container'      => false,
						'menu_class'     => 'menu',
						'depth'          => 1,
						'fallback_cb'    => 'heuvel_footer_menu_fallback',
					)
				);
				?>
			</nav>
		</div>
		<div class="footer-bottom">
			<p><?php echo wp_kses_post( heuvel_mod( 'footer_note' ) ); ?></p>
			<p>&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?></p>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
