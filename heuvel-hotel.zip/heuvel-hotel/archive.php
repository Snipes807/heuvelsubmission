<?php
/**
 * Archive template (categories, tags, dates, authors).
 *
 * @package Heuvel
 */

get_header();
?>

<header class="page-head">
	<div class="container">
		<span class="eyebrow"><?php esc_html_e( 'Archive', 'heuvel' ); ?></span>
		<h1><?php echo wp_kses_post( get_the_archive_title() ); ?></h1>
		<?php the_archive_description( '<div class="archive-description">', '</div>' ); ?>
	</div>
</header>

<?php get_template_part( 'template-parts/loop' ); ?>

<?php
get_footer();
