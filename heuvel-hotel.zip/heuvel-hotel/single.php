<?php
/**
 * Single post.
 *
 * @package Heuvel
 */

get_header();

while ( have_posts() ) :
	the_post();
	?>
	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<header class="page-head">
			<div class="container">
				<?php
				$category = get_the_category();
				if ( $category ) :
					?>
					<span class="eyebrow"><?php echo esc_html( $category[0]->name ); ?></span>
				<?php endif; ?>
				<?php the_title( '<h1>', '</h1>' ); ?>
				<p class="page-meta"><?php heuvel_posted_on(); ?></p>
			</div>
		</header>

		<div class="page-body">
			<div class="container container-narrow">
				<?php if ( has_post_thumbnail() ) : ?>
					<div class="img-frame post-thumb"><?php the_post_thumbnail( 'heuvel-wide' ); ?></div>
				<?php endif; ?>

				<div class="entry-content">
					<?php
					the_content();
					wp_link_pages( array( 'before' => '<nav class="page-links">', 'after' => '</nav>' ) );
					?>
				</div>

				<?php heuvel_entry_footer(); ?>

				<?php
				the_post_navigation(
					array(
						'prev_text' => '<span class="meta-nav">' . esc_html__( 'Previous', 'heuvel' ) . '</span><span class="post-title">%title</span>',
						'next_text' => '<span class="meta-nav">' . esc_html__( 'Next', 'heuvel' ) . '</span><span class="post-title">%title</span>',
					)
				);

				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}
				?>
			</div>
		</div>
	</article>
	<?php
endwhile;

get_footer();
