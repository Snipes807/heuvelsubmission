<?php
/**
 * Search form.
 *
 * @package Heuvel
 */

$heuvel_search_id = wp_unique_id( 'search-' );
?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label for="<?php echo esc_attr( $heuvel_search_id ); ?>">
		<span class="screen-reader-text"><?php esc_html_e( 'Search for:', 'heuvel' ); ?></span>
		<input type="search" id="<?php echo esc_attr( $heuvel_search_id ); ?>" class="search-field" placeholder="<?php esc_attr_e( 'Search…', 'heuvel' ); ?>" value="<?php echo esc_attr( get_search_query() ); ?>" name="s">
	</label>
	<button type="submit" class="btn btn-dark"><?php esc_html_e( 'Search', 'heuvel' ); ?></button>
</form>
