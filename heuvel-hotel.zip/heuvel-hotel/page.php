<?php
/**
 * Single page.
 *
 * @package Heuvel
 */

get_header();

while ( have_posts() ) :
	the_post();
	?>
	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
		<header class="page-head">
			<div class="container">
				<?php the_title( '<h1>', '</h1>' ); ?>
			</div>
		</header>

		<div class="page-body">
			<div class="container container-narrow">
				<?php if ( has_post_thumbnail() ) : ?>
					<div class="img-frame post-thumb"><?php the_post_thumbnail( 'heuvel-wide' ); ?></div>
				<?php endif; ?>

				<div class="entry-content">
					<?php
					the_content();
					wp_link_pages( array( 'before' => '<nav class="page-links">', 'after' => '</nav>' ) );
					?>
				</div>

				<?php
				if ( comments_open() || get_comments_number() ) {
					comments_template();
				}
				?>
			</div>
		</div>
	</article>
	<?php
endwhile;

get_footer();
