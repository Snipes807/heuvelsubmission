=== Heuvel Hotel ===
Requires at least: 6.3
Tested up to: 6.6
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

An editorial boutique-hotel theme.

== Setup ==

1. Upload the `heuvel-hotel` folder to wp-content/themes/ (or zip it and use Appearance → Themes → Add New → Upload).
2. Activate it.
3. Settings → Reading: set "Your homepage displays" to "A static page", pick a Home page and a Posts page (for the journal).
4. Appearance → Menus: assign menus to "Primary Menu" and "Footer Menu". Without menus, placeholder links to #about, #rooms and #book are shown.
5. Appearance → Customize → Heuvel Front Page: edit every heading, paragraph, button and image on the front page. Each section can be hidden.

Headings in the Customizer accept <em>, <strong>, <span> and <br> for the italic serif accents.
Any content written in the static Home page's editor appears between the Rooms and Booking sections.

== Copyright ==

Default images are loaded from Unsplash (https://unsplash.com/license). Replace them in the Customizer before launch.
Fonts: EB Garamond and Hanken Grotesk, SIL Open Font License, via Google Fonts.
